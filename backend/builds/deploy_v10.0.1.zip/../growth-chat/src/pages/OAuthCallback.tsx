import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

const OAuthCallback = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { checkAuthStatus } = useAuth();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('');

  useEffect(() => {
    console.log('OAuthCallback: useEffect running');
    const handleOAuthCallback = async () => {
      const token = searchParams.get('token');
      const error = searchParams.get('error');
      const code = searchParams.get('code');
      
      console.log('OAuthCallback: Token:', token ? 'Present' : 'None');
      console.log('OAuthCallback: Error:', error || 'None');
      console.log('OAuthCallback: Code:', code || 'None');

      if (error) {
        setStatus('error');
        setMessage(error || 'Authentication failed');
        return;
      }

      if (token) {
        try {
          console.log('OAuth callback received token:', token);
          
          // Store the token
          localStorage.setItem('token', token);
          
          // Check authentication status
          await checkAuthStatus();
          
          setStatus('success');
          setMessage('Authentication successful! Redirecting...');
          
          // Redirect to main page after a short delay
          setTimeout(() => {
            navigate('/', { replace: true });
          }, 2000);
        } catch (err) {
          console.error('OAuth callback error:', err);
          setStatus('error');
          setMessage('Failed to complete authentication. Please try again.');
        }
      } else {
        setStatus('error');
        setMessage('No authentication token received');
      }
    };

    handleOAuthCallback();
  }, [searchParams, navigate, checkAuthStatus]);

  const getStatusIcon = () => {
    switch (status) {
      case 'loading':
        return <Loader2 className="h-12 w-12 animate-spin text-blue-500" />;
      case 'success':
        return <CheckCircle className="h-12 w-12 text-green-500" />;
      case 'error':
        return <XCircle className="h-12 w-12 text-red-500" />;
      default:
        return <AlertCircle className="h-12 w-12 text-yellow-500" />;
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'loading':
        return 'text-blue-600';
      case 'success':
        return 'text-green-600';
      case 'error':
        return 'text-red-600';
      default:
        return 'text-yellow-600';
    }
  };

  const handleRetry = () => {
    window.location.href = '/';
  };

  const handleManualLogin = () => {
    navigate('/', { replace: true });
  };

  return (
    <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white/95 backdrop-blur-sm border-0 shadow-xl">
        <CardHeader className="text-center pb-4">
          <div className="flex justify-center mb-4">
            {getStatusIcon()}
          </div>
          <CardTitle className={`text-2xl font-bold ${getStatusColor()}`}>
            {status === 'loading' && 'Authenticating...'}
            {status === 'success' && 'Success!'}
            {status === 'error' && 'Authentication Failed'}
          </CardTitle>
          <CardDescription className="text-gray-600">
            {status === 'loading' && 'Please wait while we complete your authentication'}
            {status === 'success' && 'You have been successfully authenticated'}
            {status === 'error' && 'There was an issue with your authentication'}
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="text-center">
            <p className={`text-sm ${getStatusColor()}`}>
              {message}
            </p>
          </div>

          {status === 'error' && (
            <div className="space-y-3">
              <Button 
                onClick={handleRetry} 
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                Try Again
              </Button>
              <Button 
                onClick={handleManualLogin} 
                variant="outline" 
                className="w-full"
              >
                Go to Login
              </Button>
            </div>
          )}

          {status === 'success' && (
            <div className="text-center">
              <p className="text-sm text-gray-600">
                Redirecting to Growth Genius Chat...
              </p>
            </div>
          )}

          {status === 'loading' && (
            <div className="text-center">
              <p className="text-sm text-gray-600">
                Please wait...
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default OAuthCallback;


import { Button } from "@/components/ui/button";
import Logo from "@/components/Logo";
import { useAuth } from "@/contexts/AuthContext";
import { useState } from "react";
import LoginModal from "./LoginModal";
import { smoothScrollToElement } from "@/lib/utils";

const Navigation = ({ onOpenLogin }: { onOpenLogin?: () => void }) => {
  const { user, logout } = useAuth();
  const [showLoginModal, setShowLoginModal] = useState(false);

  // Expose the openLoginModal function to parent components
  const openLoginModal = () => {
    console.log('Navigation: openLoginModal called, setting modal to true');
    setShowLoginModal(true);
    if (onOpenLogin) {
      console.log('Navigation: Calling onOpenLogin callback with:', openLoginModal);
      onOpenLogin(openLoginModal);
    } else {
      console.log('Navigation: onOpenLogin is undefined');
    }
  };

  console.log('Navigation: Current user state:', user);

  const handleLogout = () => {
    logout();
  };

  return (
    <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-border z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Logo size="md" showText={true} />
        
        <div className="hidden md:flex items-center space-x-8">
          <a href="#features" className="text-muted-foreground hover:text-foreground transition-colors">
            Features
          </a>
          <a href="#knowledge" className="text-muted-foreground hover:text-foreground transition-colors">
            Knowledge Base
          </a>
          <a href="https://www.agentweb.pro/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors">
            About
          </a>
        </div>
        
        <div className="flex items-center space-x-4">
          {user ? (
            <>
              <span className="text-sm text-muted-foreground hidden md:block">
                {user.email}
              </span>
              <Button variant="ghost" onClick={handleLogout}>
                Sign Out
              </Button>
            </>
          ) : (
            <>
              <Button variant="ghost" onClick={openLoginModal} data-signin="true">
                Sign In
              </Button>
              <Button 
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
                onClick={() => smoothScrollToElement('chat-section', '#chat-section input[type="text"]')}
              >
                Start Chat
              </Button>
            </>
          )}
        </div>
      </div>

      <LoginModal 
        isOpen={showLoginModal} 
        onClose={() => setShowLoginModal(false)} 
      />
    </nav>
  );
};

export default Navigation;


import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
  textColor?: string;
}

const Logo = ({ size = 'md', showText = true, className = '', textColor }: LogoProps) => {
  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-12 h-12'
  };

  const textSizeClasses = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl'
  };

  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <div className={`${sizeClasses[size]} relative`}>
        {/* Main gradient background */}
        <div className="w-full h-full bg-gradient-growth rounded-lg relative overflow-hidden">
          {/* Cute brain/lightbulb hybrid icon */}
          <div className="absolute inset-0 flex items-center justify-center">
            {/* Brain stem */}
            <div className="w-3 h-2 bg-white/90 rounded-full absolute bottom-1"></div>
            {/* Main bulb shape */}
            <div className="w-4 h-4 bg-white/90 rounded-full relative">
              {/* Sparkle effects */}
              <div className="absolute -top-0.5 -right-0.5 w-1 h-1 bg-energy rounded-full animate-pulse"></div>
              <div className="absolute -bottom-0.5 -left-0.5 w-0.5 h-0.5 bg-primary rounded-full animate-pulse delay-300"></div>
              {/* Inner brain pattern */}
              <div className="absolute inset-1 rounded-full bg-gradient-to-br from-growth/30 to-energy/30"></div>
            </div>
          </div>
          
          {/* Cute shine effect */}
          <div className="absolute top-1 left-1 w-1.5 h-1.5 bg-white/60 rounded-full"></div>
        </div>
      </div>
      
      {showText && (
        <>
          <span className={`${textSizeClasses[size]} font-bold ${textColor || 'text-foreground'}`}>
            Growth Genius
          </span>
          {size !== 'sm' && (
            <span className="text-sm text-muted-foreground">
              by AgentWeb, Inc.
            </span>
          )}
        </>
      )}
    </div>
  );
};

export default Logo;

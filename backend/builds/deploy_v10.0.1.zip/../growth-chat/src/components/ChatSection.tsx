
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageCircle, Send, Zap, LogOut, Plus, Trash2, User } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import Logo from "@/components/Logo";

interface ChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface ChatSession {
  sessionId: string;
  title: string;
  messages: ChatMessage[];
  createdAt: Date;
}

const ChatSection = () => {
  const { user, logout, axios } = useAuth();
  const [message, setMessage] = useState("");

  console.log('ChatSection: Current user state:', user);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "assistant",
              content: "Welcome to Growth Genius! I'm your AI-powered growth marketing assistant. Ask me anything about startup growth strategies, and I'll share insights from 500+ successful companies.",
      timestamp: new Date()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentSession, setCurrentSession] = useState<ChatSession | null>(null);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatInputRef = useRef<HTMLInputElement>(null);

  // Helper function to format timestamp
  const formatTimestamp = (timestamp: string | Date | undefined): string => {
    if (!timestamp) return 'Just now';
    
    try {
      if (typeof timestamp === 'string') {
        return new Date(timestamp).toLocaleTimeString();
      } else if (timestamp instanceof Date) {
        return timestamp.toLocaleTimeString();
      }
      return 'Just now';
    } catch (error) {
      return 'Just now';
    }
  };

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Load chat sessions when user is authenticated
  useEffect(() => {
    console.log('ChatSection: useEffect triggered - User state changed:', user);
    console.log('ChatSection: useEffect - User details:', {
      hasUser: !!user,
      userId: user?.userId,
      email: user?.email,
      roles: user?.roles
    });
    
    if (user && user.userId) {
      console.log('ChatSection: useEffect - User authenticated, calling loadChatSessions');
      loadChatSessions();
      
      // Restore pending message from localStorage if user just logged in
      const savedMessage = localStorage.getItem('pendingMessage');
      console.log('ChatSection: useEffect - Checking localStorage for pending message:', savedMessage);
      if (savedMessage) {
        console.log('ChatSection: useEffect - Restoring pending message from localStorage:', savedMessage);
        setMessage(savedMessage);
        localStorage.removeItem('pendingMessage');
      } else {
        console.log('ChatSection: useEffect - No pending message in localStorage');
      }
    } else {
      console.log('ChatSection: useEffect - No user or invalid user, clearing sessions');
      setSessions([]);
      setCurrentSession(null);
      setMessages([
        {
          id: "welcome",
          role: "assistant",
          content: "Welcome to Growth Genius! I'm your AI-powered growth marketing assistant. Ask me anything about startup growth strategies, and I'll share insights from 500+ successful companies.",
          timestamp: new Date()
        }
      ]);
    }
  }, [user]);



  const loadChatSessions = async () => {
    if (!user || !user.userId) {
      return;
    }
    
    try {
      const response = await axios.get('/api/growth-genius/sessions');
      setSessions(response.data || []);
      
      // If no current session and sessions exist, load the first one
      if (!currentSession && response.data && response.data.length > 0) {
        loadChatSession(response.data[0].sessionId);
      } else if (currentSession) {
        // Update current session with latest data (including updated title)
        const updatedCurrentSession = response.data?.find(s => s.sessionId === currentSession.sessionId);
        if (updatedCurrentSession && updatedCurrentSession.title !== currentSession.title) {
          setCurrentSession(updatedCurrentSession);
        }
      } else if (!currentSession && (!response.data || response.data.length === 0)) {
        // No sessions exist, show welcome message for new users
        const welcomeMessage: ChatMessage = {
          id: "welcome-no-sessions",
          role: "assistant",
          content: "Welcome to Growth Genius! I'm your AI-powered growth marketing assistant. Ask me anything about startup growth strategies, and I'll share insights from 500+ successful companies.",
          timestamp: new Date()
        };
        setMessages([welcomeMessage]);
      }
    } catch (error) {
      console.error('Failed to load chat sessions:', error);
      
      // If it's an authentication error, clear the user state
      if (error.response?.status === 401) {
        logout();
      }
    }
  };

  const loadChatSession = async (sessionId: string) => {
    try {
      const response = await axios.get(`/api/growth-genius/sessions/${sessionId}`);
      const session = response.data;
      setCurrentSession(session);
      
      // Filter out system messages and only show user/assistant messages
      const chatMessages = (session.messages || []).filter(msg => 
        msg.role === 'user' || msg.role === 'assistant'
      );
      
      // Ensure all messages have unique IDs
      const messagesWithIds = chatMessages.map((msg, index) => ({
        ...msg,
        id: msg.id || `msg-${sessionId}-${index}-${Date.now()}`,
        timestamp: msg.timestamp ? new Date(msg.timestamp) : new Date()
      }));
      
      // If no messages exist, show welcome message
      if (messagesWithIds.length === 0) {
        const welcomeMessage: ChatMessage = {
          id: "welcome-existing-session",
          role: "assistant",
          content: "Welcome to Growth Genius! I'm your AI-powered growth marketing assistant. Ask me anything about startup growth strategies, and I'll share insights from 500+ successful companies.",
          timestamp: new Date()
        };
        setMessages([welcomeMessage]);
      } else {
        setMessages(messagesWithIds);
      }
    } catch (error) {
      console.error('Failed to load chat session:', error);
      
      // If it's an authentication error, clear the user state
      if (error.response?.status === 401) {
        logout();
      }
    }
  };

  const createNewSession = async () => {
    try {
      // Check if we need to refresh authentication
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('ChatSection: No token found, user needs to re-authenticate');
        // Clear user state and redirect to login
        logout();
        return null;
      }
      
      const response = await axios.post('/api/growth-genius/sessions', {});
      
      const newSession = response.data;
      setCurrentSession(newSession);
      
      // Add welcome message for new sessions
      const welcomeMessage: ChatMessage = {
        id: "welcome-new-session",
        role: "assistant",
        content: "Welcome to Growth Genius! I'm your AI-powered growth marketing assistant. Ask me anything about startup growth strategies, and I'll share insights from 500+ successful companies.",
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
      
      setSessions(prev => [newSession, ...prev]);
      
      // Focus on chat input after creating new session
      setTimeout(() => {
        chatInputRef.current?.focus();
      }, 100);
      
      return newSession; // Return the created session
    } catch (error) {
      console.error('Failed to create chat session:', error);
      
      // If it's an authentication error, clear the user state
      if (error.response?.status === 401) {
        logout();
      }
      
      return null; // Return null on error
    }
  };

  const handleSend = async () => {
    if (!message.trim()) return;
    
    if (!user) {
      // User tried to send a message but isn't signed in
      // Save the message to localStorage and show login modal
      console.log('ChatSection: User not logged in, saving message to localStorage:', message);
      localStorage.setItem('pendingMessage', message);
      setMessage("");
      
      // Show the login modal - simulate clicking Sign In
      const signInButton = document.querySelector('[data-signin="true"]') as HTMLElement;
      
      if (signInButton) {
        console.log('ChatSection: Found Sign In button, clicking it');
        signInButton.click();
      } else {
        console.log('ChatSection: Could not find Sign In button');
      }
      
      return;
    }

    console.log('ChatSection: User authenticated, checking current session');
    console.log('ChatSection: Current session:', currentSession);
    
    let sessionToUse = currentSession;
    
    if (!sessionToUse) {
      console.log('ChatSection: No current session, creating new one');
      try {
        sessionToUse = await createNewSession();
        console.log('ChatSection: Session created, new session:', sessionToUse);
      } catch (error) {
        console.error('ChatSection: Failed to create session:', error);
        return;
      }
    }

    if (!sessionToUse?.sessionId) {
      console.error('ChatSection: No valid session ID available');
      return;
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      content: message,
      role: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setMessage("");
    setIsLoading(true);

    try {
      // Check if we need to refresh authentication
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('ChatSection: No token found, user needs to re-authenticate');
        logout();
        return;
      }
      
      const response = await axios.post(`/api/growth-genius/sessions/${sessionToUse.sessionId}/messages`, {
        content: message
      });

      const { assistantMessage } = response.data;
      
      // Add AI response to messages
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        content: assistantMessage.content,
        role: 'assistant',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiMessage]);
      
      // Simple scroll to bottom after bot responds
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
      }, 100);
      
      // Refresh the sessions list to get updated titles
      loadChatSessions();
    } catch (error) {
      console.error('Failed to send message:', error);
      
      // If it's an authentication error, clear the user state
      if (error.response?.status === 401) {
        logout();
        return;
      }
      
      // Add error message
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        content: "I'm sorry, I encountered an error processing your request. Please try again.",
        role: 'assistant',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const archiveSession = async (sessionId: string) => {
    try {
      await axios.delete(`/api/growth-genius/sessions/${sessionId}`);
      setSessions(prev => prev.filter(s => s.sessionId !== sessionId));
      
      if (currentSession?.sessionId === sessionId) {
        setCurrentSession(null);
        setMessages([]);
      }
    } catch (error) {
      console.error('Failed to archive session:', error);
    }
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <section id="chat-section" className="min-h-screen bg-gradient-hero text-white flex items-center pt-24">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-hero mb-4">
              Unlock Your Startup's
              <br />
              <span className="bg-gradient-growth bg-clip-text text-transparent">
                Growth Potential
              </span>
            </h1>
                          <div className="flex items-center justify-center gap-3 mb-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-6 py-3 w-fit mx-auto">
                <div className="flex items-center gap-2 cursor-pointer hover:bg-white/20 transition-colors rounded-full px-2 py-1" onClick={() => document.getElementById('knowledge')?.scrollIntoView({ behavior: 'smooth' })}>
                  <Zap className="w-5 h-5 text-energy animate-pulse" />
                  <span className="text-sm font-medium text-energy">Silicon Valley Success Stories</span>
                </div>
                <div className="w-px h-4 bg-white/30"></div>
                <div className="flex items-center gap-2 cursor-pointer hover:bg-white/20 transition-colors rounded-full px-2 py-1" onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}>
                  <Logo size="sm" showText={false} />
                  <span className="text-sm font-bold bg-gradient-growth bg-clip-text text-transparent">GPT-5</span>
                </div>
              </div>
            

          </div>

          {/* Chat Interface */}
          <Card className="bg-white/5 backdrop-blur-sm border-white/10 h-[500px] flex flex-col">
            <CardContent className="p-0 flex flex-col h-full">
              {/* New Session Button */}
              {user && (
                <div className="flex border-b border-white/10">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={createNewSession}
                    className="text-white hover:bg-white/10 rounded-none"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    New Chat
                  </Button>
                </div>
              )}

              {/* Messages */}
              <ScrollArea className="flex-1 p-6">
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      {msg.role === 'user' ? (
                        <div className="flex items-start gap-3 max-w-[80%]">
                          <div className="bg-growth text-white p-4 rounded-lg flex-1">
                            <div className="leading-relaxed prose prose-sm max-w-none prose-invert text-white">
                              <ReactMarkdown 
                                remarkPlugins={[remarkGfm]}
                              >
                                {msg.content}
                              </ReactMarkdown>
                            </div>
                            <div className="text-xs opacity-70 mt-2">
                              {formatTimestamp(msg.timestamp)}
                            </div>
                          </div>
                          <div className="bg-growth text-white p-2 rounded-full">
                            <User className="w-4 h-4" />
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-start gap-3 max-w-[80%]">
                          <div className="bg-white/10 text-white/90 border border-white/20 p-2 rounded-full">
                            <Logo size="sm" showText={false} />
                          </div>
                          <div className="bg-white/10 text-white/90 border border-white/20 p-4 rounded-lg flex-1">
                            <div className="leading-relaxed prose prose-sm max-w-none prose-invert text-white">
                              <ReactMarkdown 
                                remarkPlugins={[remarkGfm]}
                              >
                                {msg.content}
                              </ReactMarkdown>
                            </div>
                            <div className="text-xs opacity-70 mt-2">
                              {formatTimestamp(msg.timestamp)}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-white/10 rounded-lg px-4 py-2 border border-white/20">
                        <div className="flex items-center space-x-2">
                          <Logo size="sm" showText={false} />
                          <span className="text-sm text-white/80">
                            Growth Genius is thinking...
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              {/* Input */}
              <div className="p-6 border-t border-white/10">
                <div className="flex gap-3">
                  <input
                    ref={chatInputRef}
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Ask me about startup growth strategies..."
                    className="flex-1 px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-growth focus:border-transparent"
                  />
                  <Button 
                    onClick={handleSend}
                    className="bg-growth hover:bg-growth/90 text-white px-6"
                    disabled={isLoading}
                  >
                    <Send className="w-5 h-5" />
                  </Button>
                </div>

              </div>
            </CardContent>
          </Card>

          {/* Chat Sessions Grid */}
          {user && (
            <div className="mt-8">
              <h3 className="text-lg font-semibold text-white mb-4">
                Your Chat Sessions ({sessions.length})
              </h3>
              

              
              {sessions.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {sessions.map((session) => (
                    <div
                      key={session.sessionId}
                      onClick={() => loadChatSession(session.sessionId)}
                      className={`bg-white/5 border border-white/20 rounded-lg p-4 cursor-pointer transition-all ${
                        currentSession?.sessionId === session.sessionId 
                          ? 'bg-gradient-to-r from-white/15 to-white/10 border-white/50 shadow-lg shadow-white/10 hover:bg-gradient-to-r hover:from-white/20 hover:to-white/15' 
                          : 'hover:bg-white/10 hover:border-white/30'
                      }`}
                      title={session.title || `Session ${session.sessionId.slice(-6)}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          {currentSession?.sessionId === session.sessionId && (
                            <div className="w-2 h-2 bg-growth rounded-full flex-shrink-0"></div>
                          )}
                          <h4 className={`font-medium text-white truncate ${
                            currentSession?.sessionId === session.sessionId ? 'text-white font-semibold' : ''
                          }`}>
                            {session.title || `Session ${session.sessionId.slice(-6)}`}
                          </h4>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            archiveSession(session.sessionId);
                          }}
                          className="text-white/60 hover:text-white hover:bg-white/10 p-1 h-6 w-6"
                          title="Archive session"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                      <p className="text-sm text-white/60 mb-2">
                        {Math.max(0, (session.messages?.length || 0) - 2)} messages
                      </p>
                      <p className="text-xs text-white/40">
                        {new Date(session.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-white/60">
                  <p>No chat sessions found</p>
                  <p className="text-sm mt-2">Start a new chat to create your first session</p>
                </div>
              )}
            </div>
          )}

          {/* Quick Start Prompts */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              "How did Airbnb build trust?",
              "Show me viral growth tactics",
              "B2B SaaS growth strategies"
            ].map((prompt) => (
              <Button
                key={prompt}
                variant="outline"
                className="bg-white/5 border-white/20 text-white hover:bg-white/10 p-4 h-auto text-left"
                onClick={() => setMessage(prompt)}
              >
                <MessageCircle className="w-4 h-4 mr-2 flex-shrink-0" />
                {prompt}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChatSection;



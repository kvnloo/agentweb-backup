
import Logo from "@/components/Logo";

const Footer = () => {
  return (
    <footer className="bg-secondary text-secondary-foreground py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="mb-4">
              <Logo size="md" showText={true} className="text-secondary-foreground" textColor="text-white" />
            </div>
            <p className="text-secondary-foreground/80 mb-6 max-w-md">
              Empowering startup founders with proven growth strategies from Silicon Valley's 
              most successful companies. Powered by AgentWeb, Inc.
            </p>
            <div className="text-sm text-secondary-foreground/60">
              © 2024 AgentWeb, Inc. All rights reserved.
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Product</h4>
            <ul className="space-y-2 text-sm text-secondary-foreground/80">
              <li><a href="#" className="hover:text-secondary-foreground transition-colors">Growth Genius</a></li>
              <li><a href="https://www.agentweb.pro/" target="_blank" rel="noopener noreferrer" className="hover:text-secondary-foreground transition-colors">Marketing on Autopilot</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-sm text-secondary-foreground/80">
              <li><a href="https://www.agentweb.pro/our-story" target="_blank" rel="noopener noreferrer" className="hover:text-secondary-foreground transition-colors">About Us</a></li>

              <li><a href="https://www.agentweb.pro/privacy-policy" target="_blank" rel="noopener noreferrer" className="hover:text-secondary-foreground transition-colors">Privacy Policy</a></li>
              <li><a href="https://www.agentweb.pro/terms" target="_blank" rel="noopener noreferrer" className="hover:text-secondary-foreground transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

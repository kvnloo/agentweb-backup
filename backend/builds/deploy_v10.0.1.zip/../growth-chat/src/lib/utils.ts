import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function smoothScrollToElement(elementId: string, focusSelector?: string, delay: number = 500) {
  const element = document.getElementById(elementId);
  if (element) {
    // Smooth scroll to element
    element.scrollIntoView({ 
      behavior: 'smooth', 
      block: 'start',
      inline: 'nearest'
    });
    
    // Focus on element if selector provided
    if (focusSelector) {
      setTimeout(() => {
        const focusElement = document.querySelector(focusSelector) as HTMLElement;
        if (focusElement && focusElement.focus) {
          focusElement.focus();
        }
      }, delay);
    }
  }
}

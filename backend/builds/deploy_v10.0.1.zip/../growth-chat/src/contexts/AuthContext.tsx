import React, { createContext, useContext, useEffect, useState, useCallback } from 'react'
import axios from 'axios'

interface User {
  userId: string
  email: string
  isAdmin: boolean
  roles?: ('partner' | 'customer' | 'free')[]
}

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  googleLogin: () => Promise<void>
  checkAuthStatus: () => Promise<void>
  axios: typeof axios
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  // Configure axios defaults
  axios.defaults.baseURL = import.meta.env.VITE_API_URL || 'http://localhost:3001'

  const checkAuthStatus = useCallback(async () => {
    const token = localStorage.getItem('token')
    
    if (!token) {
      setUser(null)
      setLoading(false)
      return
    }

    try {
      // Use fetch instead of axios to avoid circular dependency
      const baseURL = import.meta.env.VITE_API_URL || 'http://localhost:3001';
      const response = await fetch(`${baseURL}/api/auth/me`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      const userData = await response.json();
      setUser(userData)
    } catch (error) {
      console.error('checkAuthStatus: Auth check failed:', error)
      localStorage.removeItem('token')
      delete axios.defaults.headers.common['Authorization']
      setUser(null)
    } finally {
      setLoading(false)
    }
  }, [])

  // Check for existing token on mount
  useEffect(() => {
    const token = localStorage.getItem('token')
    
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
      checkAuthStatus()
    } else {
      setLoading(false)
    }
  }, [checkAuthStatus])

  const login = async (email: string, password: string) => {
    try {
      const response = await axios.post('/api/auth/login', { email, password })
      const { token, user: userData } = response.data
      
      // Validate user data structure
      if (!userData || !userData.userId || !userData.email) {
        console.error('Invalid user data structure:', userData);
        throw new Error('Invalid user data received from server');
      }
      
      localStorage.setItem('token', token)
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
      setUser(userData)
    } catch (error: any) {
      console.error('Login failed:', error);
      throw new Error(error.response?.data?.message || 'Login failed')
    }
  }

  const logout = () => {
    localStorage.removeItem('token')
    delete axios.defaults.headers.common['Authorization']
    setUser(null)
  }

  const googleLogin = async () => {
    const currentUrl = window.location.origin
    const googleAuthUrl = `${axios.defaults.baseURL}/api/auth/google?portal=genius`
    window.location.href = googleAuthUrl
  }



  const value: AuthContextType = {
    user,
    loading,
    login,
    logout,
    googleLogin,
    checkAuthStatus,
    axios
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

# Growth Genius Chat

Growth Genius Chat is a specialized frontend application for AgentWeb that provides an AI-powered growth marketing assistant powered by Emma. It integrates with the AgentWeb backend and uses the same authentication system as the partner and customer portals.

## Features

- 🤖 AI-powered growth marketing assistance via Emma
- 🔐 Secure authentication with AgentWeb backend
- 💬 Real-time chat interface with session management
- 🌙 Dark/light theme support with custom growth-focused design
- 📱 Responsive design for all devices
- 🔄 Chat session persistence and management
- 🎨 Beautiful gradient-based UI with growth-themed colors

## Prerequisites

- Node.js (v18 or later)
- AgentWeb backend running and accessible
- AgentWeb account (partner or customer)

## Development Setup

1. Install dependencies:

```bash
npm install
```

2. Configure environment variables:

Create a `.env` file in the root directory:

```env
VITE_API_URL=http://localhost:3001
```

3. Start the development server:

```bash
npm run dev
```

The application will be available at http://localhost:8080

## Building for Production

```bash
npm run build
```

This will create a `dist` folder with the production build.

## Production Deployment

### AWS Elastic Beanstalk

1. Build the production version and create deployment package:

```bash
cd growth-chat
VITE_API_URL=https://api.agentweb.pro \
npm run build && \
VERSION="0.21" && \
mkdir -p builds && \
zip -r "builds/deploy_v${VERSION}.zip" dist package.json package-lock.json server.js
```

2. Create a new application in Elastic Beanstalk:
   - Go to AWS Management Console > Elastic Beanstalk
   - Click "Create application"
   - Enter application name (e.g., "agentweb-growth-genius-chat")
   - Choose "Node.js" as platform
   - Upload the versioned zip file from `builds/deploy_v${VERSION}.zip`
   - Click "Create application"

3. Configure environment variables:
   - In your environment, go to Configuration > Software
   - Click "Edit"
   - Add environment variables:
     - PORT = 3000
   - Click "Apply"
   - Wait for the environment update to complete

### Environment Variables

- `VITE_API_URL`: The URL of the AgentWeb backend API (required at build time)
- `PORT`: Port for the production server (defaults to 3000)

## Integration with AgentWeb Backend

Growth Genius Chat integrates with the AgentWeb backend through:

- **Authentication**: Uses the same JWT-based auth system as partner/customer portals
- **Chat API**: Integrates with the existing chatbot service using Emma
- **User Management**: Shares user accounts and roles with the main AgentWeb system

### API Endpoints Used

- `POST /api/auth/login` - User authentication
- `GET /api/auth/me` - Get current user info
- `GET /api/auth/google` - Google OAuth login
- `GET /api/chatbot/sessions` - List chat sessions
- `POST /api/chatbot/sessions` - Create new chat session
- `GET /api/chatbot/sessions/:id` - Get chat session
- `POST /api/chatbot/sessions/:id/messages` - Send message
- `DELETE /api/chatbot/sessions/:id` - Delete chat session

## Architecture

The application is built with:

- **React 18** with TypeScript
- **Vite** for build tooling
- **Tailwind CSS** with custom growth-themed design system
- **Radix UI** for accessible components
- **Axios** for API communication
- **React Query** for data fetching
- **React Router** for navigation

## Design System

The application features a custom design system with:

- **Growth Colors**: Green and orange gradients for success and energy
- **Custom Gradients**: Hero, growth, and card gradients
- **Typography Scale**: Hero, section, and feature title classes
- **Custom Animations**: Float and pulse-glow effects
- **Responsive Design**: Mobile-first approach with breakpoint optimization

## Development

### Project Structure

```
src/
├── components/     # Reusable UI components
│   ├── ui/        # Base UI components (Button, Input, etc.)
│   ├── ChatSection.tsx      # Main chat interface
│   ├── Navigation.tsx       # Navigation with auth
│   ├── LoginModal.tsx       # Authentication modal
│   └── ...                 # Other components
├── contexts/      # React contexts (Auth, etc.)
├── lib/           # Utility functions
├── pages/         # Page components
└── main.tsx       # Application entry point
```

### Adding New Features

1. Create new components in `src/components/`
2. Add new pages in `src/pages/`
3. Update routing in `src/App.tsx`
4. Add new API integrations in the appropriate context

## Authentication Flow

1. **Unauthenticated Users**: Can view the demo chat interface
2. **Sign In**: Users can authenticate via email/password or Google OAuth
3. **Authenticated Users**: Access full Emma-powered chat with session management
4. **Session Management**: Users can create, switch between, and delete chat sessions

## Chat Functionality

- **Real-time Messaging**: Instant responses from Emma AI
- **Session Persistence**: Chat history is saved and can be resumed
- **Context Awareness**: Emma understands the growth marketing context
- **Rich Responses**: HTML-formatted responses with proper sanitization
- **Error Handling**: Graceful fallbacks for API failures

## Troubleshooting

### Common Issues

1. **Build errors**: Ensure all dependencies are installed with `npm install`
2. **API connection issues**: Verify `VITE_API_URL` is correct and backend is accessible
3. **Authentication failures**: Check that the backend JWT_SECRET is properly configured
4. **Port conflicts**: The dev server runs on port 8080 by default

### Development Tips

- Use the browser's developer tools to debug API calls
- Check the browser console for any JavaScript errors
- Verify environment variables are loaded correctly
- Test authentication flow with both email/password and Google OAuth

## Support

For support and questions:
- Check the main AgentWeb documentation
- Open an issue in the AgentWeb repository
- Contact the AgentWeb team

## License

This project is part of AgentWeb and follows the same licensing terms.
